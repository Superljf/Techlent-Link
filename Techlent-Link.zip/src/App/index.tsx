import react from 'react'
import './index.less'

export default function App() {
  return (
    <div className="app-d4cae53d-37d2-128d-7a5e-b70f778f6715">
      base configs
    </div>
  )
}